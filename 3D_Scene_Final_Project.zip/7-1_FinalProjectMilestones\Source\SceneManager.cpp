///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	// lamp key points - shared by the lamp and the lamp light
	const glm::vec3 LAMP_BASE_CENTER = glm::vec3(-1.5f, 0.0f, 5.0f);
	const glm::vec3 LAMP_ELBOW = glm::vec3(-0.8f, 5.0f, 5.0f);
	const glm::vec3 LAMP_HEAD = glm::vec3(2.2f, 6.2f, 5.0f);
	const float LAMP_SHADE_HEIGHT = 1.9f;

	// bulb sits at the open rim of the shade
	const glm::vec3 LAMP_BULB = LAMP_HEAD - glm::vec3(0.0f, LAMP_SHADE_HEIGHT, 0.0f);
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// start with an empty texture list (the count was never set
	// before, so textures could land in the wrong slots)
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;

	// free the texture memory used by the scene
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// was glGenTextures(), which made new textures instead of
		// freeing these ones
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads the texture images for the scene. The wood, wall,
 *  and steel images come from the course Utilities folder.
 *  The lamp shade and mug images are in this project's
 *  textures folder.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "desk");

	// the wood photo isn't seamless, so every other tile is mirrored
	// to hide the lines where the copies meet
	if (bReturn)
	{
		glBindTexture(GL_TEXTURE_2D, FindTextureID("desk"));
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glBindTexture(GL_TEXTURE_2D, 0);
	}

	bReturn = CreateGLTexture("../../Utilities/textures/drywall.jpg", "wall");
	bReturn = CreateGLTexture("../../Utilities/textures/stainless.jpg", "steel");
	bReturn = CreateGLTexture("../../Utilities/textures/stainless_end.jpg", "steelend");
	bReturn = CreateGLTexture("textures/lampshade_red.jpg", "shade");
	bReturn = CreateGLTexture("textures/mug_ceramic.jpg", "ceramic");
	bReturn = CreateGLTexture("textures/monitor_screen.jpg", "screen");

	// put the loaded textures into texture slots (16 max)
	BindGLTextures();
}

/***********************************************************
 *  AddMaterial()
 *
 *  Adds a material to the list. Every material uses the same
 *  gray ambient color, so only the values that change from
 *  surface to surface are passed in.
 ***********************************************************/
void SceneManager::AddMaterial(
	std::string tag,
	float ambientStrength,
	float diffuse,
	glm::vec3 specularColor,
	float shininess)
{
	OBJECT_MATERIAL material;
	material.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	material.ambientStrength = ambientStrength;
	material.diffuseColor = glm::vec3(diffuse, diffuse, diffuse);
	material.specularColor = specularColor;
	material.shininess = shininess;
	material.tag = tag;
	m_objectMaterials.push_back(material);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  One material per kind of surface. Diffuse values stay
 *  around 0.4 because the shader adds the material's diffuse
 *  once per light, so higher values washed the scene out.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	//          tag        ambient  diffuse  specular color                 shininess
	AddMaterial("wood",    0.15f,   0.40f,   glm::vec3(0.55f, 0.50f, 0.42f), 3.0f);   // varnished desk, reflects the lamp
	AddMaterial("wall",    0.30f,   0.40f,   glm::vec3(0.0f),               0.0f);   // flat paint
	AddMaterial("steel",   0.15f,   0.40f,   glm::vec3(0.9f),               4.0f);   // brushed metal
	AddMaterial("enamel",  0.18f,   0.40f,   glm::vec3(0.6f),               2.5f);   // painted lamp shade
	AddMaterial("bulb",    1.00f,   0.20f,   glm::vec3(0.0f),               0.0f);   // high ambient so it glows
	AddMaterial("ceramic", 0.18f,   0.40f,   glm::vec3(0.7f),               3.0f);   // glazed mug
	AddMaterial("coffee",  0.15f,   0.35f,   glm::vec3(0.6f),               3.0f);   // shiny liquid
	AddMaterial("paper",   0.20f,   0.40f,   glm::vec3(0.05f),              0.2f);   // book covers and pages
	AddMaterial("pencil",  0.20f,   0.40f,   glm::vec3(0.3f),               1.0f);   // painted wood
	AddMaterial("plastic", 0.18f,   0.40f,   glm::vec3(0.5f),               2.0f);   // monitor and mouse
	AddMaterial("screen",  0.45f,   0.30f,   glm::vec3(0.3f),               1.0f);   // lit screen, extra ambient
}

/***********************************************************
 *  SetLight()
 *
 *  Sets every value for one of the shader's four light
 *  slots.
 ***********************************************************/
void SceneManager::SetLight(
	int index,
	glm::vec3 position,
	glm::vec3 ambientColor,
	glm::vec3 lightColor,
	float focalStrength,
	float specularIntensity)
{
	std::string light = "lightSources[" + std::to_string(index) + "]";

	m_pShaderManager->setVec3Value(light + ".position", position);
	m_pShaderManager->setVec3Value(light + ".ambientColor", ambientColor);
	m_pShaderManager->setVec3Value(light + ".diffuseColor", lightColor);
	m_pShaderManager->setVec3Value(light + ".specularColor", lightColor);
	m_pShaderManager->setFloatValue(light + ".focalStrength", focalStrength);
	m_pShaderManager->setFloatValue(light + ".specularIntensity", specularIntensity);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Lights the scene with the Phong model (ambient, diffuse,
 *  and specular).
 *
 *  Note: the course shader takes diffuse brightness from the
 *  material, not from the light, so a light's color shows up
 *  through its ambient value. It also always adds all four
 *  light slots, so the unused slot is turned off by hand.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// 0: lamp bulb - warm point light under the shade; its wide
	//    highlight makes the shiny patch on the desk
	SetLight(0, LAMP_BULB, glm::vec3(0.07f, 0.05f, 0.01f),
		glm::vec3(1.0f, 0.85f, 0.6f), 8.0f, 0.35f);

	// 1: room light - soft white, high up in front and to the left,
	//    so the whole desk is lit
	SetLight(1, glm::vec3(-6.0f, 14.0f, 14.0f), glm::vec3(0.06f),
		glm::vec3(0.9f), 32.0f, 0.2f);

	// 2: back light - dim, behind the wall, so the backs of the objects
	//    aren't dark when the camera moves around them (the shader has
	//    no shadows, so it still reaches them, but the wall faces away
	//    from it and doesn't get a bright spot)
	SetLight(2, glm::vec3(3.0f, 10.0f, -20.0f), glm::vec3(0.0f),
		glm::vec3(0.5f), 32.0f, 0.1f);

	// 3: not used - moved far below the desk with no color or shine
	SetLight(3, glm::vec3(0.0f, -1000.0f, 0.0f), glm::vec3(0.0f),
		glm::vec3(0.0f), 1.0f, 0.0f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Loads textures, materials, lights, and the meshes the
 *  scene uses. Each mesh only has to be loaded once.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();            // desk, wall, monitor screen
	m_basicMeshes->LoadBoxMesh();              // books, monitor, stand base
	m_basicMeshes->LoadCylinderMesh();         // lamp, pencil cup, pencils
	m_basicMeshes->LoadTaperedCylinderMesh();  // mug
	m_basicMeshes->LoadConeMesh();             // lamp shade, pencil tips
	m_basicMeshes->LoadSphereMesh();           // light bulb, mouse
	m_basicMeshes->LoadPrismMesh();            // monitor stand neck
	m_basicMeshes->LoadTorusMesh(0.2f);        // mug handle
}

/***********************************************************
 *  RenderScene()
 *
 *  Draws the desk scene: the lamp from my Milestone One
 *  sketch plus the monitor, mouse, books, mug, and pencil
 *  holder from my Final Project Review breakdown. Each
 *  object has its own method.
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDesk();
	RenderMonitor();
	RenderBooks();
	RenderDeskLamp();
	RenderMouse();
	RenderCoffeeMug();
	RenderPencilCup();
}

/***********************************************************
 *  SetTransformationsAlongLine()
 *
 *  Lines up a cylinder or cone mesh (which both stand along
 *  +Y from 0 to 1) with a line from startXYZ to endXYZ. The
 *  two points need the same Z, so only a Z rotation is used:
 *  scale to the line's length, rotate to its angle, and move
 *  the base to the start point.
 ***********************************************************/
void SceneManager::SetTransformationsAlongLine(
	glm::vec3 startXYZ,
	glm::vec3 endXYZ,
	float radius)
{
	glm::vec3 direction = endXYZ - startXYZ;
	float length = glm::length(direction);

	// the mesh points straight up (90 degrees), so rotate by the
	// difference between that and the line's angle
	float lineAngle = glm::degrees(atan2(direction.y, direction.x));

	SetTransformations(
		glm::vec3(radius, length, radius),
		0.0f, 0.0f, lineAngle - 90.0f,
		startXYZ);
}

/***********************************************************
 *  DrawCylinderBetween()
 *
 *  Draws a cylinder from startXYZ to endXYZ. Ends can be left
 *  off when they're hidden, to save triangles.
 ***********************************************************/
void SceneManager::DrawCylinderBetween(
	glm::vec3 startXYZ,
	glm::vec3 endXYZ,
	float radius,
	bool bDrawEnds)
{
	SetTransformationsAlongLine(startXYZ, endXYZ, radius);
	m_basicMeshes->DrawCylinderMesh(bDrawEnds, bDrawEnds, true);
}

/***********************************************************
 *  DrawConeBetween()
 *
 *  Draws a cone from the center of its base to its tip. The
 *  base is left open since it always sits against something.
 ***********************************************************/
void SceneManager::DrawConeBetween(
	glm::vec3 baseXYZ,
	glm::vec3 tipXYZ,
	float radius)
{
	SetTransformationsAlongLine(baseXYZ, tipXYZ, radius);
	m_basicMeshes->DrawConeMesh(false);
}

/***********************************************************
 *  RenderDesk()
 *
 *  Desk top (the plane the scene sits on) and back wall.
 ***********************************************************/
void SceneManager::RenderDesk()
{
	// desk: 80 x 80 plane at y = 0 (deep enough to reach under the
	// camera; the part behind the wall is hidden)
	SetTransformations(glm::vec3(40.0f, 1.0f, 40.0f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f));

	// wood tiled 6 x 8 so each copy keeps the photo's 4:3 shape
	SetShaderTexture("desk");
	SetTextureUVScale(6.0f, 8.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPlaneMesh();

	// wall: the same size, stood upright behind the desk
	SetTransformations(glm::vec3(40.0f, 1.0f, 20.0f), 90.0f, 0.0f, 0.0f, glm::vec3(0.0f, 9.0f, -10.0f));

	// square drywall image tiled 4 x 2 so each copy stays square
	SetShaderTexture("wall");
	SetTextureUVScale(4.0f, 2.0f);
	SetShaderMaterial("wall");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  DrawLampHinge()
 *
 *  A lamp joint: two flat round plates, one on each side of
 *  the arms. Only the two end caps of a short cylinder are
 *  drawn (68 triangles), which looks like a real hinge and
 *  costs far less than a sphere (520).
 ***********************************************************/
void SceneManager::DrawLampHinge(glm::vec3 centerXYZ, float radius)
{
	const float gap = 0.36f;   // space between the plates for the arms

	// a cylinder turned 90 degrees on X runs along Z, so its two caps
	// face the front and back of the lamp
	SetTransformations(
		glm::vec3(radius, gap, radius),
		90.0f, 0.0f, 0.0f,
		centerXYZ - glm::vec3(0.0f, 0.0f, gap / 2.0f));

	SetShaderTexture("steelend");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("steel");
	m_basicMeshes->DrawCylinderMesh(true, true, false);
}

/***********************************************************
 *  RenderDeskLamp()
 *
 *  Adjustable desk lamp (about 970 triangles):
 *    base       - short wide cylinder
 *    arms       - two thin cylinders, ends hidden by joints
 *    joints     - hinge plates at the elbow and the head
 *    shade      - cone with its tip at the head joint
 *    bulb       - half sphere hanging below the shade
 ***********************************************************/
void SceneManager::RenderDeskLamp()
{
	const float baseRadius = 1.6f;
	const float baseHeight = 0.35f;
	const float shadeRadius = 1.4f;
	const glm::vec3 armStart = LAMP_BASE_CENTER + glm::vec3(0.0f, baseHeight, 0.0f);

	// base
	SetTransformations(glm::vec3(baseRadius, baseHeight, baseRadius), 0.0f, 0.0f, 0.0f, LAMP_BASE_CENTER);
	SetShaderMaterial("steel");

	SetShaderTexture("steel");
	SetTextureUVScale(3.0f, 1.0f);   // repeat around the wide base
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	SetShaderTexture("steelend");     // circular brushing on top
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// arms - brushed lines run along each arm
	SetShaderTexture("steel");
	SetTextureUVScale(1.0f, 1.0f);
	DrawCylinderBetween(armStart, LAMP_ELBOW, 0.16f, false);
	DrawCylinderBetween(LAMP_ELBOW, LAMP_HEAD, 0.15f, false);

	// joints
	DrawLampHinge(LAMP_ELBOW, 0.3f);
	DrawLampHinge(LAMP_HEAD, 0.22f);

	// bulb - the half sphere mesh is the top half, so it's flipped
	// (180 on X) to hang down just below the rim of the shade
	SetTransformations(glm::vec3(0.45f), 180.0f, 0.0f, 0.0f, LAMP_BULB - glm::vec3(0.0f, 0.1f, 0.0f));
	SetShaderColor(1.0f, 0.95f, 0.70f, 1.0f);
	SetShaderMaterial("bulb");
	m_basicMeshes->DrawHalfSphereMesh();

	// shade - the cone's origin is its base, so it's moved down one
	// shade height to put the tip on the head joint
	SetTransformations(
		glm::vec3(shadeRadius, LAMP_SHADE_HEIGHT, shadeRadius),
		0.0f, 0.0f, 0.0f,
		LAMP_HEAD - glm::vec3(0.0f, LAMP_SHADE_HEIGHT, 0.0f));
	SetShaderTexture("shade");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("enamel");
	m_basicMeshes->DrawConeMesh(false);   // open bottom
}

/***********************************************************
 *  DrawBook()
 *
 *  One closed book: a colored cover box and a slightly
 *  smaller white page block that sticks out on the right.
 ***********************************************************/
void SceneManager::DrawBook(
	glm::vec3 sizeXYZ,
	glm::vec3 centerXYZ,
	float YrotationDegrees,
	glm::vec4 coverColor)
{
	SetShaderMaterial("paper");

	// cover
	SetTransformations(sizeXYZ, 0.0f, YrotationDegrees, 0.0f, centerXYZ);
	SetShaderColor(coverColor.r, coverColor.g, coverColor.b, coverColor.a);
	m_basicMeshes->DrawBoxMesh();

	// pages - shifted right by 0.09 (turned with the book) so they
	// poke out 0.03 past the cover on that side
	float turn = glm::radians(YrotationDegrees);
	glm::vec3 pageOffset = glm::vec3(0.09f * cos(turn), 0.0f, -0.09f * sin(turn));

	SetTransformations(sizeXYZ - glm::vec3(0.12f, 0.1f, 0.1f), 0.0f, YrotationDegrees, 0.0f, centerXYZ + pageOffset);
	SetShaderColor(0.95f, 0.93f, 0.86f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderBooks()
 *
 *  Stack of three books (72 triangles). Each book's center
 *  height is the top of the one below plus half its own
 *  thickness.
 ***********************************************************/
void SceneManager::RenderBooks()
{
	const float bottom = 0.50f;   // thickness of each book
	const float middle = 0.45f;
	const float top = 0.45f;

	DrawBook(glm::vec3(3.4f, bottom, 2.4f), glm::vec3(-6.0f, bottom / 2.0f, 3.5f),
		0.0f, glm::vec4(0.70f, 0.18f, 0.16f, 1.0f));                   // red
	DrawBook(glm::vec3(3.1f, middle, 2.2f), glm::vec3(-5.85f, bottom + middle / 2.0f, 3.45f),
		-6.0f, glm::vec4(0.16f, 0.25f, 0.52f, 1.0f));                  // blue
	DrawBook(glm::vec3(2.8f, top, 2.0f), glm::vec3(-6.05f, bottom + middle + top / 2.0f, 3.5f),
		5.0f, glm::vec4(0.22f, 0.48f, 0.30f, 1.0f));                   // green
}

/***********************************************************
 *  RenderCoffeeMug()
 *
 *  Coffee mug: a tapered cylinder body (wider at the top),
 *  a thin disc of coffee inside, and half of a torus for the
 *  handle. About 1,230 triangles, most of them in the
 *  course's torus mesh.
 ***********************************************************/
void SceneManager::RenderCoffeeMug()
{
	const glm::vec3 base = glm::vec3(4.3f, 0.0f, 4.0f);   // bottom center
	const float topRadius = 0.9f;                          // the bottom is half this
	const float height = 1.9f;

	// body - the tapered mesh is narrow at the top, so it's flipped
	// (180 on X) to be wide at the top, then raised by its height
	SetTransformations(glm::vec3(topRadius, height, topRadius), 180.0f, 0.0f, 0.0f,
		base + glm::vec3(0.0f, height, 0.0f));
	SetShaderTexture("ceramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTaperedCylinderMesh(true, false, true);   // sides and the narrow end (now the bottom)

	// handle - the half torus is the top half of a ring facing the
	// camera; -90 on Z turns it to curve out to the right. After that
	// turn, the X scale sets the handle's height and Y sets its reach.
	// It sits low enough that both ends meet the slanted wall.
	SetTransformations(glm::vec3(0.55f, 0.5f, 0.75f), 0.0f, 0.0f, -90.0f,
		base + glm::vec3(0.55f, 0.95f, 0.0f));
	m_basicMeshes->DrawHalfTorusMesh();

	// coffee - thin disc 0.3 below the rim; at that height the wall's
	// radius is about 0.83, so the disc is a little smaller
	SetTransformations(glm::vec3(0.79f, 0.02f, 0.79f), 0.0f, 0.0f, 0.0f,
		base + glm::vec3(0.0f, height - 0.3f, 0.0f));
	SetShaderColor(0.25f, 0.14f, 0.07f, 1.0f);
	SetShaderMaterial("coffee");
	m_basicMeshes->DrawCylinderMesh(true, false, false);
}

/***********************************************************
 *  DrawPencil()
 *
 *  One sharpened pencil: a painted cylinder and a bare wood
 *  cone tip (250 triangles).
 ***********************************************************/
void SceneManager::DrawPencil(
	glm::vec3 startXYZ,
	glm::vec3 tipXYZ,
	glm::vec4 bodyColor)
{
	const float radius = 0.09f;
	const float tipLength = 0.38f;

	glm::vec3 direction = glm::normalize(tipXYZ - startXYZ);
	glm::vec3 bodyEnd = tipXYZ - direction * tipLength;

	SetShaderMaterial("pencil");

	// body - the bottom end is hidden in the cup and the top is
	// covered by the tip, so neither end is drawn
	SetShaderColor(bodyColor.r, bodyColor.g, bodyColor.b, bodyColor.a);
	DrawCylinderBetween(startXYZ, bodyEnd, radius, false);

	// sharpened tip
	SetShaderColor(0.87f, 0.70f, 0.50f, 1.0f);
	DrawConeBetween(bodyEnd, tipXYZ, radius);
}

/***********************************************************
 *  RenderPencilCup()
 *
 *  Pencil holder: an open steel cylinder with three pencils
 *  (about 890 triangles).
 ***********************************************************/
void SceneManager::RenderPencilCup()
{
	const glm::vec3 base = glm::vec3(7.4f, 0.0f, 2.5f);   // bottom center
	const float radius = 0.75f;
	const float height = 2.1f;

	// pencils start low inside the holder so the walls hide their ends
	DrawPencil(base + glm::vec3(-0.25f, 0.5f, 0.0f), base + glm::vec3(-0.75f, 4.1f, 0.0f),
		glm::vec4(0.95f, 0.75f, 0.15f, 1.0f));    // yellow
	DrawPencil(base + glm::vec3(0.0f, 0.5f, 0.15f), base + glm::vec3(0.15f, 4.4f, 0.15f),
		glm::vec4(0.20f, 0.42f, 0.80f, 1.0f));    // blue
	DrawPencil(base + glm::vec3(0.25f, 0.5f, -0.15f), base + glm::vec3(0.9f, 3.9f, -0.15f),
		glm::vec4(0.80f, 0.22f, 0.22f, 1.0f));    // red

	// holder - sides only, since the top is open and the bottom sits
	// on the desk
	SetTransformations(glm::vec3(radius, height, radius), 0.0f, 0.0f, 0.0f, base);
	SetShaderTexture("steel");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("steel");
	m_basicMeshes->DrawCylinderMesh(false, false, true);
}

/***********************************************************
 *  RenderMonitor()
 *
 *  Computer monitor at the back of the desk (about 35
 *  triangles):
 *    screen frame - thin box
 *    screen       - plane on the front of the frame
 *    neck         - triangular prism, wide at the bottom
 *    stand base   - flat box
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	const glm::vec3 center = glm::vec3(0.8f, 5.3f, -3.0f);   // middle of the screen
	const glm::vec3 frameSize = glm::vec3(9.0f, 5.4f, 0.35f);

	SetShaderMaterial("plastic");
	SetShaderColor(0.12f, 0.12f, 0.13f, 1.0f);   // black plastic

	// frame
	SetTransformations(frameSize, 0.0f, 0.0f, 0.0f, center);
	m_basicMeshes->DrawBoxMesh();

	// stand base - flat box on the desk under the screen
	SetTransformations(glm::vec3(3.0f, 0.2f, 2.2f), 0.0f, 0.0f, 0.0f, glm::vec3(center.x, 0.1f, -3.2f));
	m_basicMeshes->DrawBoxMesh();

	// neck - the prism mesh is a triangle stretched along Y. Turning
	// it 90 on Z and then -90 on X stretches it along X instead and
	// stands the triangle up, wide at the base and narrow at the top.
	// After those turns, X scale = depth at the bottom, Y = width, and
	// Z = height. Its top tucks in behind the frame.
	SetTransformations(glm::vec3(1.6f, 0.6f, 3.0f), -90.0f, 0.0f, 90.0f, glm::vec3(center.x, 1.7f, -3.35f));
	m_basicMeshes->DrawPrismMesh();

	// screen - a plane stood up (90 on X) just in front of the frame,
	// a little smaller so a black border shows around it
	SetTransformations(
		glm::vec3(frameSize.x / 2.0f - 0.25f, 1.0f, frameSize.y / 2.0f - 0.25f),
		90.0f, 0.0f, 0.0f,
		center + glm::vec3(0.0f, 0.0f, frameSize.z / 2.0f + 0.01f));
	SetShaderTexture("screen");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screen");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderMouse()
 *
 *  Computer mouse: the top half of a sphere, so it's flat on
 *  the bottom and sits on the desk (260 triangles).
 ***********************************************************/
void SceneManager::RenderMouse()
{
	// wider front to back than side to side, and low, turned a little
	SetTransformations(glm::vec3(0.4f, 0.25f, 0.62f), 0.0f, -10.0f, 0.0f, glm::vec3(1.9f, 0.0f, 6.4f));
	SetShaderColor(0.86f, 0.86f, 0.88f, 1.0f);   // light gray plastic
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawHalfSphereMesh();
}
