///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	// half the height of the orthographic view; big enough to fit
	// everything on the desk from the starting camera spot
	const float ORTHO_HALF_HEIGHT = 6.8f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;

	// match yaw and pitch to the Front direction above, otherwise the
	// view jumps on the first mouse move (pitch = atan(0.5 / 2))
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = -14.04f;
	// the default sensitivity (0.01) barely turns the camera
	g_pCamera->MouseSensitivity = 0.1f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// hide the cursor and keep it in the window so the mouse can
	// turn the camera (ESC closes the window)
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// raw mouse input skips Windows pointer acceleration
	if (glfwRawMouseMotionSupported())
	{
		glfwSetInputMode(window, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE);
	}

	// set the mouse callbacks after the cursor is captured - when they
	// were set first, the cursor jumping to the center counted as a
	// mouse move and turned the camera away at startup
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Called by GLFW when the mouse moves. Turns the camera:
 *  left/right changes yaw and up/down changes pitch.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	// remember the first position so the first offset is zero
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// how far the mouse moved since the last call
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos;   // reversed: screen y goes down

	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Called by GLFW when the scroll wheel turns. Scroll up to
 *  move faster, down to move slower.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	// the camera lowers its speed for positive values, so the wheel
	// value is flipped to make scrolling up speed it up
	// (the camera keeps the speed between 0.1 and 45)
	g_pCamera->ProcessMouseScroll((float)-yOffset);
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Keyboard controls:
 *    W / S   forward / backward
 *    A / D   left / right
 *    Q / E   up / down
 *    P / O   perspective / orthographic view
 *    ESC     close the window
 *
 *  Movement is scaled by the frame time so it runs at the
 *  same speed on any computer.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	if (NULL == g_pCamera)
	{
		return;
	}

	// switch projections; the camera itself stays where it is
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}

	// forward and backward
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// up and down
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}
}

/***********************************************************
 *  GetPerspectiveProjection()
 *
 *  3D view: things farther away look smaller.
 ***********************************************************/
glm::mat4 ViewManager::GetPerspectiveProjection()
{
	return glm::perspective(
		glm::radians(g_pCamera->Zoom),
		(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
		0.1f, 100.0f);
}

/***********************************************************
 *  GetOrthographicProjection()
 *
 *  2D view: everything keeps its size no matter how far away
 *  it is. The width follows the window shape so nothing
 *  gets stretched.
 ***********************************************************/
glm::mat4 ViewManager::GetOrthographicProjection()
{
	float halfWidth = ORTHO_HALF_HEIGHT * (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

	// the near plane is set behind the camera (-50) so the bottom edge
	// of the view still reaches the desk; with 0.1 those rays started
	// below the desk and showed the wall underneath it
	return glm::ortho(
		-halfWidth, halfWidth,
		-ORTHO_HALF_HEIGHT, ORTHO_HALF_HEIGHT,
		-50.0f, 100.0f);
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Handles input, then sends the camera's view matrix and
 *  the current projection matrix to the shader.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the
	// event queue
	ProcessKeyboardEvents();

	// same camera in both modes, only the projection changes
	view = g_pCamera->GetViewMatrix();

	if (bOrthographicProjection)
	{
		projection = GetOrthographicProjection();
	}
	else
	{
		projection = GetPerspectiveProjection();
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}
