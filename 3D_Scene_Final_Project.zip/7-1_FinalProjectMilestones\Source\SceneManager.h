///////////////////////////////////////////////////////////////////////////////
// shadermanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

	// scene setup
	void LoadSceneTextures();
	void DefineObjectMaterials();
	void SetupSceneLights();

	// add one material to the material list
	void AddMaterial(
		std::string tag,
		float ambientStrength,
		float diffuse,
		glm::vec3 specularColor,
		float shininess);

	// set every value for one light slot in the shader
	void SetLight(
		int index,
		glm::vec3 position,
		glm::vec3 ambientColor,
		glm::vec3 lightColor,
		float focalStrength,
		float specularIntensity);

	// helpers for shapes that run between two points
	void SetTransformationsAlongLine(
		glm::vec3 startXYZ,
		glm::vec3 endXYZ,
		float radius);
	void DrawCylinderBetween(
		glm::vec3 startXYZ,
		glm::vec3 endXYZ,
		float radius,
		bool bDrawEnds = true);
	void DrawConeBetween(
		glm::vec3 baseXYZ,
		glm::vec3 tipXYZ,
		float radius);

	// objects in the scene
	void RenderDesk();
	void RenderDeskLamp();
	void RenderBooks();
	void RenderCoffeeMug();
	void RenderPencilCup();
	void RenderMonitor();
	void RenderMouse();

	// smaller parts that are drawn more than once
	void DrawLampHinge(
		glm::vec3 centerXYZ,
		float radius);
	void DrawBook(
		glm::vec3 sizeXYZ,
		glm::vec3 centerXYZ,
		float YrotationDegrees,
		glm::vec4 coverColor);
	void DrawPencil(
		glm::vec3 startXYZ,
		glm::vec3 tipXYZ,
		glm::vec4 bodyColor);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

};